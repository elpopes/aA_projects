def my_map(array, &blc)
    new_array = []
    array.each {|ele| new_array << blc.call(ele)}
    new_array
end

def my_select(array, &blc)
    new_array = []
    array.each {|ele| new_array << ele if blc.call(ele)}
    new_array
end

def my_count(array, &blc)
    count = 0
    array.each {|ele| count += 1 if blc.call(ele)}
    count
end

def my_any?(array, &blc)
    count = 0
    array.each {|ele| count += 1 if blc.call(ele)}
    count > 0
end

def my_all?(array, &blc)
    count = 0
    array.each {|ele| count += 1 if blc.call(ele)}
    count == array.size
end

def my_none?(array, &blc)
    count = 0
    array.each {|ele| count += 1 if blc.call(ele)}
    count == 0
end
