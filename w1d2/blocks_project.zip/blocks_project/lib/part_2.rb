def all_words_capitalized?(words_array)
    words_array.all? {|word| word == word.capitalize}
end

def no_valid_url?(urls_array)
    urls_array.none? do |url|
        url.end_with?('com') ||
        url.end_with?('net') ||
        url.end_with?('io') ||
        url.end_with?('org')
    end
end

def any_passing_students?(students_array)
    students_array.any? {|student_hash| student_hash[:grades].sum / student_hash[:grades].length > 75}
end